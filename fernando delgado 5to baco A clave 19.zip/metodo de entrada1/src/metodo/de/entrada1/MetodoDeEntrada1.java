/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package metodo.de.entrada1;
import java.util.Scanner;
/**
 *
 * @author estudiante
 */
public class MetodoDeEntrada1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // primera serie
        System.out.println("Delwin Fernando Herrera Delgado");
        System.out.println("5to baco A");
        // segund serie 
        String a;
          String b;
          int c;
        System.out.println("ingrese su Usuario");
        Scanner n1 = new Scanner(System.in);
        a = n1.nextLine();  
       
        System.out.println("ingrese su nombre");
        Scanner n2 = new Scanner(System.in);
        b = n2.nextLine();
        
        
        System.out.println("ingrese su edad");
        Scanner n3 = new Scanner(System.in);
        c = n3.nextInt();
        
         System.out.println("su usuario es "+a);
        System.out.println("su nombre es "+b);
        System.out.println("su edad es "+c);
        // tercera cerie
        if (c>17){
            System.out.println("tiene dpi");
        } else {
             System.out.println("es niño");
    }
        // cuarta cerie
        int k;
        
        
       System.out.println("ingrese la cantidad");
        Scanner n4 = new Scanner(System.in);
        k = n4.nextInt();
        
      //for(k=0 k<10 1++;)
      
      System.out.println(+k);System.out.println(+k);System.out.println(+k);System.out.println(+k);System.out.println(+k);System.out.println(+k);System.out.println(+k);System.out.println(+k);System.out.println(+k);System.out.println(+k);
      
    // tabla de multiplicacion
     System.out.println("por1="+k*1);
      System.out.println("por2="+k*2);
       System.out.println("por3="+k*3);
        System.out.println("por4="+k*4);
         System.out.println("por5="+k*5);
          System.out.println("por6="+k*6);
           System.out.println("por7="+k*7);
            System.out.println("por8="+k*8);
             System.out.println("por9="+k*9);
              System.out.println("por10="+k*10);
}
}